const fs = require('fs');
const express = require("express");
const https = require("https");
var cookieParser = require('cookie-parser');
const pg = require('pg')

//https://aem.run/posts/2021-05-30-installing-postgresql-on-alpine-rpi/

const config = {
  user: 'root',           // Your PostgreSQL username
  host: '',              // The host where your PostgreSQL server is running (use 'localhost' if local)
  database: '',
  password: '',
  port: 5432
};

const studentKey = "iJIgaQHfzroQOIrZDCtD7B24B1oolg3aon1qt34btf0";
const adminKey = "iTmb9f3M0Uv57YmX7B2loocQrb3GzWFe1WuvWo15SxY"

var database_content
const createTable = `
  CREATE TABLE IF NOT EXISTS users (
    ID INTEGER PRIMARY KEY AUTOINCREMENT,
    Project INTEGER,
    Admin BOOL NOT NULL
    Username VARCHAR(32)
    HashedPassword VARCHAR(72)
    GradYear INTEGER
  );
`;
const pool = new pg.Pool(config);
pool.connect((err, client, done) => {
  if (err) throw err;
  client.query(createTable, (err, res) => {
      if (err){
        console.log(err.stack);
      }
      pool.end()
  })
});

  

const severinfo = {
  key: fs.readFileSync('key.pem', 'utf8'),
  cert: fs.readFileSync('server.crt', 'utf8')
};


const app = express();
app.use(express.static(__dirname + '/public'));
app.use(cookieParser());

//this url should route to the raw project on github 
//                                             username       repo name               branch
const url = "https://raw.githubusercontent.com/0ddSh33p/CitProjectsSiteBeta/refs/heads/main";


app.get("/", async (req, res)=> {
  const data = await getPageData(url + "/html/index.html")
  //once data has recived its value, send it to the user
  res.send(data);
  res.end();
});

app.get("/student", async (req, res) => {
  if (validateStudent(req)) {
    const data = await getPageData(url + "/html/student.html");
    res.send(data); // Send data only if the student is valid
  } else {
    return res.redirect("https://localhost:3000"); // Redirect only if invalid
  }
});

app.get("/logout", async (req, res) => {
  // Clear the cookie
  res.clearCookie("myCITProjectKey");

  // Redirect only once to avoid the headers being sent multiple times
  return res.redirect("https://localhost:3000");
});

//backend request -->

app.get("/tryUser/:user/:pass", async (req, res) =>{
  var myName = req.params.user;
  var myPass = req.params.pass;
  var prop = 0;

  pool.connect((err, client, done) => {
    if (err) throw err;
    client.query('SELECT * FROM users', (err, res) => {
        if (err){
          console.log(err.stack);
        }else{
          for(var user in res){
            if(myName == user[Username] && myPass + user[Password].substring(65) == user[Password]){
              if(user[Admin]){
                prop = 2;
              } else {
                prop = 1;
              }
            }
          }
        }
        pool.end()
    });
  });

  res.status(200).json({propType: prop})
  res.end();
});

app.get("/css/master.css", async (req, res)=> {
  const data = await getPageData(url + "/css/master.css")
  res.send(data);
  res.end();
});




//Additional functions -->

function validateStudent(req){
  let valid = false;
  if(req.cookies["myCITProjectKey"] != null){
    if(req.cookies["myCITProjectKey"] == studentKey || req.cookies["myCITProjectKey"] == adminKey){
      valid = true;
    }
  }
  return valid;
}

function validateAdmin(req){
  let valid = false;
  if(req.cookies["myCITProjectKey"] != null){
    if( req.cookies["myCITProjectKey"] == adminKey){
      valid = true;
    }
  }
  return valid;
}

function getPageData (localRoute) {
    
  return new Promise((resolve, reject) => {
      https.get(localRoute, (res) => {
        let data = '';
  
        // A chunk of data has been received.
        res.on('data', (chunk) => {
          data += chunk;
        });
  
        // The whole response has been received.
        res.on('end', () => {
          resolve(data); // Return the data once it's fully received.
        });
  
      }).on("error", (err) => {
          reject("Error: " + err.message); // Reject the promise if there’s an error.
      });
  });
}

async function loadFile(filePath) {
  try {
    const response = await fetch(filePath);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const text = await response.text();
    return text;
  } catch (error) {
    console.error("Failed to load file:", error);
    return null;
  }
}

https.createServer(severinfo, app).listen(3000, () => {
  console.log("HTTPS server running on https://localhost:3000");
});